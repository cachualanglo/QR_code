package com.attendance.controller;

import com.attendance.dto.request.UpdateLocationRequest;
import com.attendance.dto.response.DayDetailResponse;
import com.attendance.dto.response.DayStatsResponse;
import com.attendance.entity.CompanyLocation;
import com.attendance.entity.User;
import com.attendance.service.AdminService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final AdminService adminService;

    /**
     * Cập nhật vị trí & giờ làm việc
     */
    @PutMapping("/location")
    public ResponseEntity<CompanyLocation> updateLocation(@Valid @RequestBody UpdateLocationRequest request) {
        return ResponseEntity.ok(adminService.updateLocation(request));
    }

    /**
     * Xem thông tin vị trí hiện tại
     */
    @GetMapping("/location")
    public ResponseEntity<CompanyLocation> getLocation() {
        return ResponseEntity.ok(adminService.getLocation());
    }

    /**
     * Danh sách nhân viên
     */
    @GetMapping("/employees")
    public ResponseEntity<List<Map<String, Object>>> getEmployees() {
        List<Map<String, Object>> employees = adminService.getAllEmployees().stream()
                .map(e -> {
                    Map<String, Object> map = new java.util.HashMap<>();
                    map.put("id", e.getId());
                    map.put("employeeCode", e.getEmployeeCode());
                    map.put("username", e.getUsername());
                    map.put("role", e.getRole());
                    return map;
                })
                .collect(Collectors.toList());
        return ResponseEntity.ok(employees);
    }

    /**
     * Xem thống kê điểm danh của 1 nhân viên
     */
    @GetMapping("/employees/{userId}/stats")
    public ResponseEntity<List<DayStatsResponse>> getEmployeeStats(
            @PathVariable Long userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return ResponseEntity.ok(adminService.getEmployeeStats(userId, startDate, endDate));
    }

    /**
     * Xem chi tiết điểm danh của 1 nhân viên trong 1 ngày
     */
    @GetMapping("/employees/{userId}/detail")
    public ResponseEntity<DayDetailResponse> getEmployeeDayDetail(
            @PathVariable Long userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return ResponseEntity.ok(adminService.getEmployeeDayDetail(userId, date));
    }
}
