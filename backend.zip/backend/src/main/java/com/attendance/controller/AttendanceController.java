package com.attendance.controller;

import com.attendance.dto.request.AttendanceRequest;
import com.attendance.dto.response.AttendanceResponse;
import com.attendance.dto.response.DayDetailResponse;
import com.attendance.dto.response.DayStatsResponse;
import com.attendance.entity.User;
import com.attendance.repository.UserRepository;
import com.attendance.service.AttendanceService;
import com.attendance.service.StatsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@RequiredArgsConstructor
public class AttendanceController {

    private final AttendanceService attendanceService;
    private final StatsService statsService;
    private final UserRepository userRepository;

    /**
     * Check-in hoặc Check-out
     */
    @PostMapping
    public ResponseEntity<AttendanceResponse> checkInOrOut(
            @Valid @RequestBody AttendanceRequest request,
            Authentication authentication) {
        return ResponseEntity.ok(attendanceService.checkInOrOut(request, authentication.getName()));
    }

    /**
     * Xem thống kê điểm danh theo khoảng ngày
     */
    @GetMapping("/stats")
    public ResponseEntity<List<DayStatsResponse>> getStats(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            Authentication authentication) {
        // Lấy userId từ username
        Long userId = getUserId(authentication);
        return ResponseEntity.ok(statsService.getDayStats(userId, startDate, endDate));
    }

    /**
     * Xem chi tiết điểm danh 1 ngày
     */
    @GetMapping("/detail")
    public ResponseEntity<DayDetailResponse> getDetail(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            Authentication authentication) {
        Long userId = getUserId(authentication);
        return ResponseEntity.ok(statsService.getDayDetail(userId, date));
    }

    private Long getUserId(Authentication authentication) {
        return userRepository.findByUsername(authentication.getName())
                .map(User::getId)
                .orElse(1L);
    }
}
