package com.attendance.controller;

import com.attendance.dto.request.GenerateQrRequest;
import com.attendance.dto.response.QrResponse;
import com.attendance.service.QrService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/qr")
@RequiredArgsConstructor
public class QrController {

    private final QrService qrService;

    /**
     * Admin tạo QR code mới
     */
    @PostMapping("/generate")
    public ResponseEntity<QrResponse> generateQr(
            @Valid @RequestBody GenerateQrRequest request,
            Authentication authentication) {
        return ResponseEntity.ok(qrService.generateQr(request, authentication.getName()));
    }
}
