package com.attendance.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceRequest {

    @NotBlank(message = "QR token không được để trống")
    private String qrToken;

    @NotNull(message = "Vĩ độ không được để trống")
    private Double lat;

    @NotNull(message = "Kinh độ không được để trống")
    private Double lng;

    private Double accuracy;  // Sai số GPS, nullable, mặc định 5.0 nếu null
}
