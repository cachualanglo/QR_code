package com.attendance.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenerateQrRequest {

    @NotNull(message = "Loại QR không được để trống")
    private String type;  // CHECK_IN hoặc CHECK_OUT
}
