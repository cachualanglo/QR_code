package com.attendance.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AttendanceResponse {

    private Boolean ok;
    private String action;      // CHECK_IN / CHECK_OUT
    private String message;
    private Double distanceMeters;
}
