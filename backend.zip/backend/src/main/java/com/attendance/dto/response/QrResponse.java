package com.attendance.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QrResponse {

    private String token;       // UUID string
    private Long expiresIn;    // TTL in seconds (15)
    private String type;        // CHECK_IN / CHECK_OUT
}
