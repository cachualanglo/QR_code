package com.attendance.repository;

import com.attendance.entity.QrSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface QrSessionRepository extends JpaRepository<QrSession, Long> {

    // Tìm QR token theo UUID
    Optional<QrSession> findByToken(UUID token);

    // Đánh dấu QR đã dùng
    @Modifying
    @Query("UPDATE QrSession q SET q.usedAt = :usedAt, q.usedByUser.id = :userId WHERE q.token = :token AND q.usedAt IS NULL")
    int markAsUsed(@Param("token") UUID token, @Param("userId") Long userId, @Param("usedAt") LocalDateTime usedAt);

    // Dọn QR expired (optional cleanup)
    @Modifying
    @Query("DELETE FROM QrSession q WHERE q.expiresAt < :now AND q.usedAt IS NULL")
    int deleteExpired(@Param("now") LocalDateTime now);
}
