package com.attendance.service;

import com.attendance.dto.request.AttendanceRequest;
import com.attendance.dto.response.AttendanceResponse;
import com.attendance.entity.AttendanceRecord;
import com.attendance.entity.CompanyLocation;
import com.attendance.entity.QrSession;
import com.attendance.entity.User;
import com.attendance.exception.BusinessException;
import com.attendance.repository.AttendanceRecordRepository;
import com.attendance.repository.CompanyLocationRepository;
import com.attendance.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;

@Slf4j
@Service
@RequiredArgsConstructor
public class AttendanceService {

    private static final ZoneId ZONE_VN = ZoneId.of("Asia/Ho_Chi_Minh");
    private static final double GPS_MIN_ACCURACY_FLOOR = 5.0;

    private final AttendanceRecordRepository attendanceRecordRepository;
    private final CompanyLocationRepository companyLocationRepository;
    private final UserRepository userRepository;
    private final QrService qrService;

    @Transactional
    public AttendanceResponse checkInOrOut(AttendanceRequest request, String username) {
        QrSession session = qrService.validateQr(request.getQrToken());

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new BusinessException("USER_NOT_FOUND", "Không tìm thấy người dùng"));

        CompanyLocation location = companyLocationRepository.findFirstByOrderByIdAsc()
                .orElseThrow(() -> new BusinessException("NO_LOCATION", "Chưa cấu hình vị trí công ty"));

        double distance = calculateDistance(
                request.getLat(), request.getLng(),
                location.getLatitude(), location.getLongitude()
        );

        if (distance > location.getRadiusMeters()) {
            throw new BusinessException("OUT_OF_RANGE",
                    String.format("Vị trí ngoài phạm vi cho phép. Khoảng cách: %.1fm, Bán kính: %dm",
                            distance, location.getRadiusMeters()));
        }

        if (request.getAccuracy() != null && request.getAccuracy() > GPS_MIN_ACCURACY_FLOOR) {
            log.warn("GPS accuracy below floor: {}m > {}m for user {}", request.getAccuracy(), GPS_MIN_ACCURACY_FLOOR, username);
        }

        LocalDate today = LocalDate.now(ZONE_VN);
        String qrType = session.getType();

        if ("CHECK_IN".equals(qrType)) {
            return processCheckIn(user, session, location, today, distance, request.getLat(), request.getLng(), request.getAccuracy());
        } else if ("CHECK_OUT".equals(qrType)) {
            return processCheckOut(user, session, today, distance, request.getLat(), request.getLng(), request.getAccuracy());
        } else {
            throw new BusinessException("INVALID_QR_TYPE", "Loại QR không hợp lệ");
        }
    }

    private AttendanceResponse processCheckIn(User user, QrSession session, CompanyLocation location,
                                               LocalDate today, double distance, double lat, double lng, Double accuracy) {
        var existing = attendanceRecordRepository.findByUserIdAndRecordDate(user.getId(), today);
        if (existing.isPresent()) {
            throw new BusinessException("ALREADY_CHECKED_IN", "Đã check-in hôm nay");
        }

        LocalTime checkInTime = LocalTime.now(ZONE_VN);
        boolean isLate = checkInTime.isAfter(location.getCheckInEnd());

        AttendanceRecord record = AttendanceRecord.builder()
                .user(user)
                .recordDate(today)
                .checkInTime(LocalDateTime.now(ZONE_VN))
                .checkInLat(lat)
                .checkInLng(lng)
                .checkInDistanceM(distance)
                .checkInAccuracy(accuracy != null ? accuracy : 0.0)
                .checkInQrToken(session.getToken())
                .build();

        attendanceRecordRepository.save(record);
        qrService.markQrUsed(session, user);

        String message = isLate ? "Check-in thành công (ĐẾN MUỘN)" : "Check-in thành công (ĐÚNG GIỜ)";

        log.info("User {} checked in at {}, distance={}m, late={}", user.getUsername(), checkInTime, distance, isLate);

        return AttendanceResponse.builder()
                .ok(true)
                .action("CHECK_IN")
                .message(message)
                .distanceMeters(distance)
                .build();
    }

    private AttendanceResponse processCheckOut(User user, QrSession session,
                                                LocalDate today, double distance, double lat, double lng, Double accuracy) {
        var recordOpt = attendanceRecordRepository.findByUserIdAndRecordDate(user.getId(), today);
        if (recordOpt.isEmpty()) {
            throw new BusinessException("NOT_CHECKED_IN", "Chưa check-in hôm nay");
        }

        AttendanceRecord record = recordOpt.get();
        if (record.getCheckOutTime() != null) {
            throw new BusinessException("ALREADY_CHECKED_OUT", "Đã check-out hôm nay");
        }

        record.setCheckOutTime(LocalDateTime.now(ZONE_VN));
        record.setCheckOutLat(lat);
        record.setCheckOutLng(lng);
        record.setCheckOutDistanceM(distance);
        record.setCheckOutAccuracy(accuracy != null ? accuracy : 0.0);

        attendanceRecordRepository.save(record);
        qrService.markQrUsed(session, user);

        log.info("User {} checked out at {}", user.getUsername(), record.getCheckOutTime());

        return AttendanceResponse.builder()
                .ok(true)
                .action("CHECK_OUT")
                .message("Check-out thành công")
                .distanceMeters(distance)
                .build();
    }

    public double calculateDistance(double lat1, double lng1, double lat2, double lng2) {
        final double R = 6371000;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}
