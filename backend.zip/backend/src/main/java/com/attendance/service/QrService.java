package com.attendance.service;

import com.attendance.dto.request.GenerateQrRequest;
import com.attendance.dto.response.QrResponse;
import com.attendance.entity.QrSession;
import com.attendance.entity.User;
import com.attendance.exception.BusinessException;
import com.attendance.repository.QrSessionRepository;
import com.attendance.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class QrService {

    private static final long QR_TTL_SECONDS = 15;

    private final QrSessionRepository qrSessionRepository;
    private final UserRepository userRepository;

    @Transactional
    public QrResponse generateQr(GenerateQrRequest request, String adminUsername) {
        User admin = userRepository.findByUsername(adminUsername)
                .orElseThrow(() -> new BusinessException("USER_NOT_FOUND", "Không tìm thấy admin"));

        String type = request.getType().toUpperCase();
        if (!type.equals("CHECK_IN") && !type.equals("CHECK_OUT")) {
            throw new BusinessException("INVALID_QR_TYPE", "Loại QR phải là CHECK_IN hoặc CHECK_OUT");
        }

        QrSession session = QrSession.builder()
                .token(UUID.randomUUID())
                .type(type)
                .expiresAt(LocalDateTime.now().plus(QR_TTL_SECONDS, ChronoUnit.SECONDS))
                .createdByUser(admin)
                .build();

        qrSessionRepository.save(session);

        log.info("QR session created: type={}, token={}, expiresAt={}", type, session.getToken(), session.getExpiresAt());

        return QrResponse.builder()
                .token(session.getToken().toString())
                .expiresIn(QR_TTL_SECONDS)
                .type(type)
                .build();
    }

    @Transactional
    public QrSession validateQr(String tokenString) {
        UUID token;
        try {
            token = UUID.fromString(tokenString);
        } catch (IllegalArgumentException e) {
            throw new BusinessException("QR_INVALID", "QR token không hợp lệ");
        }

        QrSession session = qrSessionRepository.findByToken(token)
                .orElseThrow(() -> new BusinessException("QR_NOT_FOUND", "QR token không tồn tại"));

        if (session.isExpired()) {
            throw new BusinessException("QR_EXPIRED", "QR đã hết hạn (TTL 15 giây)");
        }

        if (!session.isValid()) {
            throw new BusinessException("QR_ALREADY_USED", "QR đã được sử dụng");
        }

        return session;
    }

    @Transactional
    public void markQrUsed(QrSession session, User user) {
        qrSessionRepository.markAsUsed(session.getToken(), user.getId(), LocalDateTime.now());
        log.info("QR token {} marked as used by user {}", session.getToken(), user.getUsername());
    }

    @Scheduled(fixedRate = 300000)
    @Transactional
    public void cleanupExpiredSessions() {
        int deleted = qrSessionRepository.deleteExpired(LocalDateTime.now());
        if (deleted > 0) {
            log.info("Cleaned up {} expired QR sessions", deleted);
        }
    }
}
